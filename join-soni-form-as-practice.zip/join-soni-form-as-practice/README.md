# Join Soni Form as practice

A Pen created on CodePen.io. Original URL: [https://codepen.io/Jeweldisk/pen/GRYMpOO](https://codepen.io/Jeweldisk/pen/GRYMpOO).

